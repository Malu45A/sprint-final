# Solicita o número de sócios
verificar_socios = int(input("Digite a Quantidade de pessoas do clube: "))

# Cria uma lista para armazenar os nomes dos sócios
lista = []

# Preenche a lista com os nomes dos sócios
for i in range(verificar_socios):
    nome = input(f"Digite o nome do sócio {i+1}: ")  # Solicita o nome de cada sócio
    lista.append(nome)  # Adiciona o nome à lista

# Solicita o nome a ser procurado
x = input("Qual o nome que deseja procurar? ")

# Verifica se o nome está na lista e exibe a mensagem apropriada
if x in lista:
    print(x, "pertence ao clube")  # Se o nome for encontrado, exibe que pertence ao clube
else:
    print(x, "não pertence ao clube")  # Se o nome não for encontrado, exibe que não pertence
