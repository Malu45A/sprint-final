esferas_descodificadas = []  # Lista que irá armazenar os nomes das esferas decodificadas

# Função para calcular o deslocamento com base na soma dos valores das letras e o número do dia
def calcular_soma_deslocamento(nome_esfera, numero_dia):
    # Calcula a soma dos valores das letras no nome da esfera
    soma_letras = sum(
        ord(letra) - ord('A') + 1 if letra.isupper() else ord(letra) - ord('a') + 1 
        for letra in nome_esfera if letra.isalpha()
    )
    return soma_letras + numero_dia  # Soma o valor das letras com o número do dia e retorna o total

# Laço que vai repetir 5 vezes para processar as 5 esferas
for contador_esfera in range(1, 6):
    # Solicita o nome da esfera ao usuário
    nome_esfera = input("Digite o nome da esfera (Gembu, Byakko, Suzaku, Seiryu, Songoku): ")
    # Solicita o número correspondente ao dia da semana
    numero_dia = int(input("Digite o número que condiz com o dia da semana: "))
    # Chama a função para calcular o deslocamento com base no nome da esfera e no dia
    soma_deslocamento = calcular_soma_deslocamento(nome_esfera, numero_dia)

    esfera_descodificada = ""  # Variável para armazenar o nome decodificado da esfera

    # Itera sobre cada caractere no nome da esfera
    for caractere in nome_esfera:
        if caractere.isalpha():  # Verifica se o caractere é uma letra
            codigo_ascii = ord(caractere)  # Obtém o valor ASCII do caractere
            # Aplica o deslocamento, mantendo dentro dos limites do alfabeto (26 letras)
            codigo_ascii += (soma_deslocamento % 26)

            if caractere.isupper():  # Caso o caractere seja uma letra maiúscula
                if codigo_ascii > ord('Z'):  # Se ultrapassar 'Z', retorna ao início do alfabeto
                    codigo_ascii -= 26
                elif codigo_ascii < ord('A'):  # Se for menor que 'A', retorna ao final do alfabeto
                    codigo_ascii += 26
            else:  # Caso o caractere seja uma letra minúscula
                if codigo_ascii > ord('z'):  # Se ultrapassar 'z', retorna ao início do alfabeto
                    codigo_ascii -= 26
                elif codigo_ascii < ord('a'):  # Se for menor que 'a', retorna ao final do alfabeto
                    codigo_ascii += 26

            # Converte o valor ASCII de volta para uma letra e adiciona ao nome decodificado
            esfera_descodificada += chr(codigo_ascii)
        else:
            # Caso não seja uma letra (espaços ou símbolos), adiciona diretamente ao nome decodificado
            esfera_descodificada += caractere

    # Adiciona o nome decodificado da esfera à lista de esferas
    esferas_descodificadas.append(esfera_descodificada)
    # Mostra a palavra decodificada para a esfera atual
    print(f"Palavra descodificada {contador_esfera}: {esfera_descodificada}")

# Junta todos os nomes decodificados para formar o "Segredo de Sheng Long"
print("Segredo de Sheng Long:")
segredo_final = "".join(esferas_descodificadas)  # Combina todas as esferas decodificadas em uma única string
print(segredo_final)  # Mostra o segredo final