# Função para verificar se todos os discos são válidos.
def verifica_discos(discos):
    erros = []
    for i in range(len(discos)):
        if not isinstance(discos[i], list):
            erros.append(f"Erro no disco {i}: valor '{discos[i]}' não é uma lista de inteiros.")
            continue
        for disco in discos[i]:
            if not isinstance(disco, int):
                erros.append(f"Erro no sub-disco {disco} da lista {i}: valor não é um inteiro.")
    if erros:
        for erro in erros:
            print(erro)
        return False
    return True

# Função para calcular o tempo total
def calcula_tempo_total(discos):
    total_time = 0
    for lista in discos:
        if type(lista) != list:
            print("Erro: Um dos elementos não é uma lista.")
            return total_time
        for disco in lista:
            if type(disco) != int:
                print("Erro: Um dos discos não é um número inteiro.")
                return total_time
            total_time += disco
    return total_time

# Função que recebe a lista de discos e define os tempos para cada tipo de disco.
def tempo_por_tipo(discos):
    tempo = {"grande": 5, "medio": 3, "pequeno": 1}
    for i in range(len(discos)):
        if not isinstance(discos[i], list):
            print(f"Erro: Elemento {i} não é uma lista.")
            continue
        for j in range(len(discos[i])):
            if discos[i][j] > 10:
                discos[i][j] = tempo["grande"]
            elif discos[i][j] > 5:
                discos[i][j] = tempo["medio"]
            else:
                discos[i][j] = tempo["pequeno"]
    return discos

# Função que simula atrasos adicionais baseados em condições externas.
def calcula_atraso(tempo):
    atraso = 0
    if tempo > 20:
        atraso += 5
    elif tempo < 0:
        atraso = -1
    return atraso

# Função principal que inicia o programa.
def main():
    discos = [[12, 8, 7], [5, 3], [15, 6, 9]]  # Exemplo de dados de discos.

    if not verifica_discos(discos):
        print("Erro nos dados dos discos. Verifique e tente novamente.")
        return

    tempo_discs = tempo_por_tipo(discos)
    tempo_total = calcula_tempo_total(tempo_discs)

    if tempo_total is None:
        print("Erro: Não foi possível calcular o tempo total corretamente.")
        return

    atraso = calcula_atraso(tempo_total)

    if atraso == -1:
        print("Erro no cálculo do atraso.")
    else:
        tempo_total += atraso  # O atraso é adicionado ao tempo total

    print("O tempo total para empilhar os discos é: ", tempo_total)

# Chama a função principal
main()
