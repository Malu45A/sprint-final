import json  # Biblioteca para trabalhar com arquivos e dados JSON
import os  # Biblioteca para manipulação de arquivos e caminhos

# Define a classe principal do sistema
class EstudioAuroraExecution:
    # Método construtor para inicializar o objeto da classe
    def __init__(self, nome, localizacao):
        self.nome = nome  # Nome do estúdio
        self.localizacao = localizacao  # Localização do estúdio
        self.aulas_agendadas = []  # Lista para armazenar aulas agendadas
        self.clientes = []  # Lista para armazenar clientes do estúdio

    # Método para agendar uma aula
    def agendar_aula(self, aula):
        self.aulas_agendadas.append(aula)  # Adiciona a aula à lista de aulas agendadas
        print(f"Aula '{aula}' agendada com sucesso.")  # Confirmação

    # Método para cancelar uma aula
    def cancelar_aula(self, aula):
        if aula in self.aulas_agendadas:  # Verifica se a aula está na lista
            self.aulas_agendadas.remove(aula)  # Remove a aula
            print(f"Aula '{aula}' cancelada com sucesso.")  # Confirmação
        else:
            print(f"Aula '{aula}' não encontrada.")  # Caso a aula não exista

    # Método para rastrear o progresso de um aluno
    def rastrear_progresso(self, aluno):
        if aluno in self.clientes:  # Verifica se o aluno está registrado
            print(f"Acompanhamento do progresso de {aluno}: Bem-vindo ao seu progresso no estúdio Aurora Execution.")
        else:
            print(f"Aluno {aluno} não encontrado.")  # Caso o aluno não exista

    # Método para oferecer uma aula personalizada a um aluno
    def oferecer_aula_personalizada(self, aluno):
        if aluno in self.clientes:  # Verifica se o aluno está registrado
            print(f"Oferecendo uma aula personalizada para o aluno {aluno}.")
        else:
            print(f"Aluno {aluno} não encontrado.")  # Caso o aluno não exista

    # Método para gerenciar eventos especiais no estúdio
    def gerenciar_evento_especial(self, evento):
        print(f"Evento especial '{evento}' organizado com sucesso.")  # Confirmação do evento

    # Método para adicionar um novo cliente
    def adicionar_cliente(self, cliente):
        if cliente not in self.clientes:  # Verifica se o cliente não está na lista
            self.clientes.append(cliente)  # Adiciona o cliente
            print(f"Cliente {cliente} adicionado com sucesso.")  # Confirmação
        else:
            print(f"Cliente {cliente} já existe.")  # Caso o cliente já esteja registrado

    # Método para remover um cliente
    def remover_cliente(self, cliente):
        if cliente in self.clientes:  # Verifica se o cliente está registrado
            self.clientes.remove(cliente)  # Remove o cliente
            print(f"Cliente {cliente} removido com sucesso.")  # Confirmação
        else:
            print(f"Cliente {cliente} não encontrado.")  # Caso o cliente não exista

    # Método para salvar os dados do estúdio em um arquivo JSON
    def salvar_dados(self, arquivo):
        # Dicionário com os dados do estúdio
        dados_estudio = {
            "nome": self.nome,
            "localizacao": self.localizacao,
            "aulas_agendadas": self.aulas_agendadas,
            "clientes": self.clientes
        }
        try:
            with open(arquivo, 'w') as f:  # Abre o arquivo para escrita
                json.dump(dados_estudio, f, indent=4)  # Salva os dados no arquivo
            print(f"Dados do estúdio salvos no arquivo {arquivo}.")  # Confirmação
        except Exception as e:
            print(f"Erro ao salvar os dados: {e}")  # Mensagem de erro

    # Método para carregar os dados do estúdio de um arquivo JSON
    def carregar_dados(self, arquivo):
        if os.path.exists(arquivo):  # Verifica se o arquivo existe
            try:
                with open(arquivo, 'r') as f:  # Abre o arquivo para leitura
                    dados_estudio = json.load(f)  # Carrega os dados do arquivo
                # Atualiza os atributos do objeto com os dados carregados
                self.nome = dados_estudio["nome"]
                self.localizacao = dados_estudio["localizacao"]
                self.aulas_agendadas = dados_estudio["aulas_agendadas"]
                self.clientes = dados_estudio["clientes"]
                print(f"Dados do estúdio carregados a partir do arquivo {arquivo}.")  # Confirmação
            except Exception as e:
                print(f"Erro ao carregar os dados: {e}")  # Mensagem de erro
        else:
            print(f"O arquivo {arquivo} não existe. Não foi possível carregar os dados.")  # Mensagem caso o arquivo não exista


# Função principal para interação com o usuário
def menu():
    print("Bem-vindo ao Estúdio Aurora Execution!")  # Mensagem de boas-vindas

    # Solicita informações do estúdio
    nome_estudio = input("Digite o nome do estúdio: ")
    localizacao_estudio = input("Digite a localização do estúdio: ")
    estudio = EstudioAuroraExecution(nome_estudio, localizacao_estudio)  # Cria o objeto do estúdio

    # Carrega os dados do arquivo, se existirem
    arquivo_dados = "dados_estudio.json"
    estudio.carregar_dados(arquivo_dados)

    while True:  # Loop principal do menu
        print("\nEscolha uma opção:")
        print("1. Adicionar cliente")
        print("2. Remover cliente")
        print("3. Agendar aula")
        print("4. Cancelar aula")
        print("5. Rastrear progresso de aluno")
        print("6. Oferecer aula personalizada")
        print("7. Gerenciar evento especial")
        print("8. Salvar dados")
        print("9. Sair")

        opcao = input("Opção: ")  # Solicita a escolha do usuário

        if opcao == "1":  # Adicionar cliente
            cliente = input("Digite o nome do cliente para adicionar: ")
            estudio.adicionar_cliente(cliente)

        elif opcao == "2":  # Remover cliente
            cliente = input("Digite o nome do cliente para remover: ")
            estudio.remover_cliente(cliente)

        elif opcao == "3":  # Agendar aula
            aula = input("Digite o nome da aula para agendar: ")
            estudio.agendar_aula(aula)

        elif opcao == "4":  # Cancelar aula
            aula = input("Digite o nome da aula para cancelar: ")
            estudio.cancelar_aula(aula)

        elif opcao == "5":  # Rastrear progresso
            aluno = input("Digite o nome do aluno para rastrear o progresso: ")
            estudio.rastrear_progresso(aluno)

        elif opcao == "6":  # Oferecer aula personalizada
            aluno = input("Digite o nome do aluno para oferecer aula personalizada: ")
            estudio.oferecer_aula_personalizada(aluno)

        elif opcao == "7":  # Gerenciar evento especial
            evento = input("Digite o nome do evento especial (ex: Retiro de Yoga): ")
            estudio.gerenciar_evento_especial(evento)

        elif opcao == "8":  # Salvar dados
            estudio.salvar_dados(arquivo_dados)

        elif opcao == "9":  # Sair
            print("Saindo do sistema. Até logo!")
            break

        else:  # Entrada inválida
            print("Opção inválida. Tente novamente.")

# Executa o menu
menu()
