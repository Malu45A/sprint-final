
# Função para exibir o estado atual das torres
def exibir_estado(torres):
    print("\nEstado atual das torres:")
    for i, torre in enumerate(torres, 1):
        print(f"Torre {i}: {torre}")

# Função para validar se o movimento é permitido
def validar_movimento(torres, origem, destino):
    if not torres[origem]:  # Verifica se a torre de origem está vazia
        print("Erro: A torre de origem está vazia.")
        return False
    if torres[destino] and torres[origem][-1] > torres[destino][-1]:  # Verifica a regra dos discos
        print("Erro: Não é permitido colocar um disco maior sobre um menor.")
        return False
    return True

# Função para movimentar o disco entre as torres
def movimentar_disco(torres, origem, destino):
    disco = torres[origem].pop()  # Remove o disco do topo da torre de origem
    torres[destino].append(disco)  # Adiciona o disco ao topo da torre de destino

# Função para verificar se o jogo foi concluído com sucesso
def checar_vitoria(torres, total_discos):
    return len(torres[2]) == total_discos  # Verifica se todos os discos estão na Torre 3

# Função que gerencia o jogo manual
def jogar_torre_hanoi(total_discos):
    torres = [list(range(total_discos, 0, -1)), [], []]  # Inicializa as torres com os discos
    exibir_estado(torres)  # Exibe o estado inicial das torres

    while True:  # Loop principal do jogo
        try:
            # Solicita ao jogador as torres de origem e destino
            origem = int(input("\nEscolha a torre de origem (1, 2 ou 3): ")) - 1
            destino = int(input("Escolha a torre de destino (1, 2 ou 3): ")) - 1

            # Verifica se as entradas estão dentro do intervalo permitido
            if origem not in range(3) or destino not in range(3):
                print("Erro: Escolha uma torre válida (1, 2 ou 3).")  # Exibe mensagem de erro
                continue  # Retorna ao início do loop

            # Valida o movimento solicitado
            if validar_movimento(torres, origem, destino):
                movimentar_disco(torres, origem, destino)  # Realiza o movimento
                exibir_estado(torres)  # Exibe o estado atualizado das torres

            # Verifica se o jogador venceu o jogo
            if checar_vitoria(torres, total_discos):
                print("\nParabéns! Você concluiu o desafio da Torre de Hanoi!")  # Mensagem de vitória
                break  # Sai do loop principal
        except ValueError:
            print("Erro: Digite apenas números inteiros para as torres.")  # Mensagem para entradas inválidas

# Função para exibir uma introdução ao jogo
def mostrar_introducao():
    print("\nBem-vindo ao jogo da Torre de Hanoi!")
    print("O objetivo é mover todos os discos da primeira torre para a terceira,")
    print("obedecendo às seguintes regras:")
    print("1. Você pode mover apenas um disco por vez.")
    print("2. Um disco maior nunca pode ficar sobre um menor.")
    print("3. Utilize as três torres para facilitar os movimentos.")

# Função principal que inicia o jogo
def iniciar_jogo():
    mostrar_introducao()  # Exibe as informações iniciais do jogo
    num_discos = int(input("Digite o número de discos: "))  # Permite ao jogador definir o número de discos
    jogar_torre_hanoi(num_discos)  # Inicia o jogo manual com o número de discos informado

iniciar_jogo()  # Chama a função principal para começar o jogo

