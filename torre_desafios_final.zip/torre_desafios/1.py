# Função para calcular o total do pedido
def calcular_total_pedido(itens):
    # Inicializa a variável total com 0
    total = 0.0

    # Itera sobre a lista de itens, somando os preços
    for item, preco in itens:
        total += preco

    return total


# Exemplo de uso
itens_pedido = [("Lanche A", 10.00), ("Lanche B", 15.50), ("Suco", 5.00)]
total = calcular_total_pedido(itens_pedido)

print(f"Total do pedido: R${total:.2f}")
