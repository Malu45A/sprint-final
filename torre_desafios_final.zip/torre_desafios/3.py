def calcular_custo_funeral(idade, tipo_caixao, flores):

# Custo base depende da idade
    if idade <= 12:
        custo_base = 2000 # Crianças
    elif 13 <= idade <= 60:
        custo_base = 4000 # Adultos
    else:
        custo_base = 3000 # Idosos

# Adicionando custo do caixão
    if tipo_caixao == 'simples':
        custo_caixao = 1000
    elif tipo_caixao == 'intermediário':
        custo_caixao = 2500
    elif tipo_caixao == 'luxo':
        custo_caixao = 5000
    else:
        raise ValueError("Tipo de caixão inválido. Escolha entre 'simples', 'intermediário' ou 'luxo'.")

# Custo adicional para flores
    custo_flores = 500 if flores else 0

# Custo total
    custo_total = custo_base + custo_caixao + custo_flores

    return custo_total

# Exemplo de uso
idade = int(input("Digite a sua idade: "))
tipo_caixao = input("Digite o tipo do caixão: ")
flores = True

custo = calcular_custo_funeral(idade, tipo_caixao, flores)
print(f"O custo total do funeral é: R${custo:.2f}")

