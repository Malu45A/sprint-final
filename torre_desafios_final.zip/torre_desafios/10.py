# Define a classe Aluno com seus atributos e métodos
class Aluno:
    # Método construtor que inicializa o aluno com peso e altura
    def _init_(self, peso, altura):
        # Inicializa os atributos do aluno
        self.peso = peso  # Peso do aluno (kg)
        self.altura = altura  # Altura do aluno (m)
        self.imc = self.calcular_imc()  # Calcula o IMC logo ao criar o aluno
        self.percentual_gordura = 0.0  # Inicializa o percentual de gordura em 0%
        self.massa_muscular = 0.0  # Inicializa a massa muscular em 0 kg
        self.oxigenacao = 0.0  # Inicializa a oxigenação em 0%
        self.frequencia_cardiaca = 0.0  # Inicializa a frequência cardíaca em 0 bpm
        self.foco_mental = 0.0  # Inicializa o foco mental em 0
        self.tempo_disponivel = 0.0  # Inicializa o tempo disponível para treino em 0 horas

    # Método para calcular o IMC (Índice de Massa Corporal) com base no peso e altura
    def calcular_imc(self):
        # IMC = peso / (altura ** 2)
        return self.peso / (self.altura ** 2)

    # Método para atualizar as métricas do aluno com base no treino e tempo
    def atualizar_metricas(self, aumento_massa, reducao_gordura, aumento_foco, aumento_frequencia, reducao_oxigenacao,
                           tempo):
        """
        Atualiza as métricas do aluno com base no tempo disponível para treino.
        O aumento nas métricas depende do tempo disponível relativo ao tempo de treino do aluno.
        """
        proporcao = tempo / self.tempo_disponivel if self.tempo_disponivel > 0 else 0  # Calcula a proporção do tempo
        self.massa_muscular += aumento_massa * proporcao  # Atualiza a massa muscular com base na proporção do tempo
        self.percentual_gordura -= reducao_gordura * proporcao  # Atualiza o percentual de gordura
        self.foco_mental += aumento_foco * proporcao  # Atualiza o foco mental
        self.frequencia_cardiaca += aumento_frequencia * proporcao  # Atualiza a frequência cardíaca
        self.oxigenacao -= reducao_oxigenacao * proporcao  # Atualiza a oxigenação

    # Método para exibir as métricas do aluno
    def exibir_metricas(self):
        """Exibe as métricas do aluno de forma formatada"""
        # Exibe cada métrica do aluno com duas casas decimais
        print(f"IMC: {self.imc:.2f}")  # IMC do aluno
        print(f"Percentual de Gordura: {self.percentual_gordura:.2f}%")  # Percentual de gordura
        print(f"Massa Muscular: {self.massa_muscular:.2f} kg")  # Massa muscular
        print(f"Oxigenação: {self.oxigenacao:.2f}%")  # Oxigenação
        print(f"Frequência Cardíaca: {self.frequencia_cardiaca:.2f} bpm")  # Frequência cardíaca
        print(f"Foco Mental: {self.foco_mental:.2f}")  # Foco mental

# Função principal que inicia o programa e coleta os dados do aluno
def main():
    print("Bem-vindo à Sala do Templo de CaniSama!")  # Mensagem de boas-vindas

    # Coleta de dados do aluno
    peso = float(input("Digite seu peso (kg): "))  # Solicita o peso do aluno
    altura = float(input("Digite sua altura (m): "))  # Solicita a altura do aluno

    # Criação de um objeto Aluno com peso e altura fornecidos
    aluno = Aluno(peso, altura)

    # Definindo as métricas iniciais
    aluno.percentual_gordura = float(input("Digite seu percentual de gordura (%): "))  # Percentual de gordura
    aluno.massa_muscular = float(input("Digite sua massa muscular (kg): "))  # Massa muscular
    aluno.oxigenacao = float(input("Digite sua oxigenação (%): "))  # Oxigenação
    aluno.frequencia_cardiaca = float(input("Digite sua frequência cardíaca (bpm): "))  # Frequência cardíaca
    aluno.foco_mental = float(input("Digite seu foco mental: "))  # Foco mental
    aluno.tempo_disponivel = float(input("Digite o tempo disponível para treinar (em horas): "))  # Tempo disponível

    # Dicionário de treinos com dados sobre aumento de massa, redução de gordura, aumento de foco, etc.
    treinos = {
        "Toguro": {"massa": 1.2, "gordura": 0.2, "foco": 0.67, "frequencia": 0, "oxigenacao": 0, "tempo": 200},
        "Baki": {"massa": 0.7, "gordura": 0.25, "foco": -0.05, "frequencia": 0, "oxigenacao": 0, "tempo": 300},
        "Saitama": {"massa": -0.02, "gordura": 0.75, "foco": 0, "frequencia": 0.05, "oxigenacao": 0, "tempo": 350},
        "JulinNaQuebrada": {"massa": 1.5, "gordura": 0.3, "foco": 0, "frequencia": 0, "oxigenacao": 0.04, "tempo": 150},
        "CrackRRiani": {"massa": 2.0, "gordura": 0.45, "foco": 0, "frequencia": 0.6, "oxigenacao": 0.3, "tempo": 20},
    }

    # Exibe os treinos disponíveis para o aluno escolher
    print("\nTreinos disponíveis:")
    for i, treino in enumerate(treinos.keys(), start=1):
        print(f"{i}. {treino}")  # Exibe o nome do treino com seu número

    # Solicita ao usuário que escolha um treino
    escolha = int(input("Escolha um treino (1-5): "))

    # Escolhe o treino baseado na escolha do usuário (número)
    treino_escolhido = list(treinos.keys())[escolha - 1]
    treino = treinos[treino_escolhido]  # Obtém os dados do treino escolhido

    # Atualiza as métricas do aluno com base no treino escolhido
    aluno.atualizar_metricas(
        aumento_massa=treino["massa"],
        reducao_gordura=treino["gordura"],
        aumento_foco=treino["foco"],
        aumento_frequencia=treino["frequencia"],
        reducao_oxigenacao=treino["oxigenacao"],
        tempo=treino["tempo"]
    )

    # Exibe as métricas após o treino
    aluno.exibir_metricas()

# Chama a função principal para iniciar o programa
main()  # Inicia a execução do programa