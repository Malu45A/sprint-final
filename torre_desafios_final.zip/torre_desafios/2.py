# Função que verifica se o medicamento requer prescrição médica
def verificar_prescricao(nome_medicamento):
    # Dicionário que mapeia medicamentos e se requerem ou não receita
    medicamentos = {
        "Paracetamol": False,
        "Ibuprofeno": False,
        "Amoxicilina": True,
        "Diazepam": True,
        "Aspirina": False,
        "Clonazepam": True,
        "Omeprazol": True
    }

    # Retorna True ou False com base no medicamento fornecido
    # O .capitalize() é usado para garantir que a busca seja case-insensitive
    return medicamentos.get(nome_medicamento.capitalize(), False)

# Solicita ao usuário o nome do medicamento
prescricao = input("Digite o nome do medicamento: ").strip()  # .strip() remove espaços extras

# Verifica se o medicamento requer receita médica e exibe a mensagem correspondente
if verificar_prescricao(prescricao):  # Se o medicamento requer receita
    print("True, o medicamento requer receita médica.")
else:  # Se o medicamento não requer receita
    print("False, o medicamento não requer receita médica.")
