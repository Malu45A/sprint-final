# Solicita ao usuário o preço do produto e o valor do desconto
preco = float(input("Digite o preço do produto: "))  # Preço do produto
desconto = float(input("Digite o desconto: "))  # Desconto percentual

# Calcula o valor do desconto com base no preço e na porcentagem de desconto
valor_do_desconto = preco * desconto / 100  # Calcula o valor do desconto

# Calcula o valor que o cliente deverá pagar após o desconto
pagar = preco - valor_do_desconto  # Subtrai o valor do desconto do preço original

# Exibe os resultados formatados
# Exibe a porcentagem de desconto e o preço original formatados com 2 casas decimais
print("Um desconto de %5.2f %% do produto de R$%7.2f" % (desconto, preco))

# Exibe o valor do desconto calculado, formatado com 2 casas decimais
print("Vale R$ %7.2f." % valor_do_desconto)

# Exibe o valor final a ser pago após o desconto, também com 2 casas decimais
print("O valor a pagar é de R$ %7.2f" % pagar)
