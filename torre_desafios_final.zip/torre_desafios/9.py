# Dicionário de frangos e seus preços
frangos = {
    "Frango Shun": 60.00,  # Preço do Frango Shun
    "Frango Misty": 80.00,  # Preço do Frango Misty
    "Frango Mime": 89.00,  # Preço do Frango Mime
    "Frango Jabu": 55.00,  # Preço do Frango Jabu
    "Frango Saga Grande Mestre": 100.00,  # Preço do Frango Saga Grande Mestre
    "AssaFenix": 52.00,  # Preço do frango AssaFenix
}

# Dicionário de combos e seus preços
pacotes = {
    "Combo bronze": 120.00,  # Preço do Combo bronze
    "Combo prata": 180.00,  # Preço do Combo prata
    "Combo ouro": 300.00,  # Preço do Combo ouro
}

# Lista de compras realizadas (para o relatório)
compras = []  # Inicializa uma lista vazia para armazenar as compras

# Função para exibir os frangos e pacotes disponíveis
def listar_frangos_pacotes():
    """Exibe a lista de frangos e pacotes disponíveis para compra."""
    print("\nFrangos Disponíveis:")
    # Loop que percorre o dicionário 'frangos' e exibe o nome e preço de cada frango
    for frango, preco in frangos.items():
        print(f"{frango}: R${preco:.2f}")  # Exibe o nome do frango e seu preço formatado

    print("\nPacotes Especiais:")
    # Loop que percorre o dicionário 'pacotes' e exibe o nome e preço de cada pacote
    for pacote, preco in pacotes.items():
        print(f"{pacote}: R${preco:.2f}")  # Exibe o nome do pacote e seu preço formatado


# Função para realizar uma compra
def fazer_compra():
    """Permite realizar uma compra de frangos ou pacotes."""
    print("\nEscolha o frango ou pacote que deseja comprar:")
    listar_frangos_pacotes()  # Exibe os frangos e pacotes disponíveis

    # Loop para adicionar múltiplos itens
    while True:
        # Solicita ao usuário que escolha o frango ou pacote ou digite 'sair' para sair
        escolha = input("\nDigite o nome do frango ou pacote (ou 'sair' para voltar): ").strip()

        # Se o usuário digitar 'sair', a função encerra e retorna ao menu principal
        if escolha.lower() == 'sair':
            break

        # Verifica se o item escolhido está no dicionário de frangos ou pacotes
        if escolha in frangos or escolha in pacotes:
            try:
                # Solicita ao usuário a quantidade do item desejado
                quantidade = int(input(f"Quantos '{escolha}' você deseja comprar? "))
                if quantidade <= 0:  # Verifica se a quantidade é maior que zero
                    print("Erro: A quantidade deve ser maior que zero.")
                    continue  # Se a quantidade for inválida, pede ao usuário para tentar novamente

                # Determina o preço do item escolhido (frango ou pacote)
                preco = frangos.get(escolha, pacotes.get(escolha))
                # Calcula o total da compra (preço * quantidade)
                total = preco * quantidade
                # Registra a compra na lista de compras
                compras.append((escolha, quantidade, total))
                # Exibe uma mensagem de sucesso com o valor total da compra
                print(f"Compra de {quantidade} '{escolha}' realizada com sucesso! Total: R${total:.2f}")
            except ValueError:  # Captura erros de entrada não numérica
                print("Erro: Por favor, digite uma quantidade válida (número inteiro).")
        else:
            # Se o item não for encontrado nos dicionários, exibe uma mensagem de erro
            print("Erro: Frango ou pacote não encontrado. Verifique o nome e tente novamente.")
        
        # Pergunta ao usuário se deseja adicionar mais itens
        continuar = input("\nDeseja adicionar mais itens? (s/n): ").strip().lower()
        if continuar != 's':  # Se a resposta não for 's', o loop é interrompido
            break


# Função para mostrar o relatório de compras
def exibir_relatorio():
    """Exibe o relatório detalhado de todas as compras realizadas."""
    print("\nRelatório de Compras:")
    # Verifica se existem compras registradas
    if not compras:
        print("Nenhuma compra realizada até o momento.")
    else:
        # Loop que percorre a lista de compras e exibe os detalhes de cada compra
        for compra in compras:
            print(f"{compra[0]} - Quantidade: {compra[1]} - Total: R${compra[2]:.2f}")

    # Calcula e exibe o total geral das compras
    total_compras = sum(compra[2] for compra in compras)
    print(f"\nTotal geral de compras: R${total_compras:.2f}")


# Função para exibir o menu e gerenciar as escolhas do usuário
def exibir_menu_principal():
    """Exibe o menu principal e lida com as escolhas do usuário."""
    while True:
        # Exibe as opções do menu principal
        print("\n=== Menu Principal ===")
        print("1. Listar frangos e pacotes")
        print("2. Realizar compra")
        print("3. Mostrar relatório de compras")
        print("4. Sair")

        # Solicita ao usuário que escolha uma opção
        opcao = input("Escolha uma opção: ").strip()

        if opcao == "1":
            listar_frangos_pacotes()  # Lista os frangos e pacotes disponíveis
        elif opcao == "2":
            fazer_compra()  # Realiza uma compra
        elif opcao == "3":
            exibir_relatorio()  # Mostra o relatório de compras
        elif opcao == "4":
            print("Saindo... Obrigado por comprar com a AssaFenix!")
            break  # Encerra o programa
        else:
            # Se o usuário digitar uma opção inválida, exibe uma mensagem de erro
            print("Opção inválida. Por favor, escolha uma opção válida.")


# Função principal
def iniciar_sistema():
    """Inicia o sistema de compras da AssaFenix."""
    # Exibe uma mensagem de boas-vindas
    print("Bem-vindo à AssaFenix! O melhor lugar para comprar frangos assados e pacotes especiais!")
    # Chama o menu principal, que gerencia a interação com o usuário
    exibir_menu_principal()  # Chama o menu principal


iniciar_sistema()  # Chama a função principal para rodar o programa