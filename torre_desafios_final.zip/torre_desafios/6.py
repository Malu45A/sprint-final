import random  # Importando o módulo random para gerar números aleatórios

# Entrada de dados do usuário
nome = input("Digite seu nome: ")  # Solicita o nome do usuário
idade = int(input("Digite sua idade: "))  # Solicita a idade do usuário e converte para inteiro
sexo = input("Digite seu sexo: ")  # Solicita o sexo do usuário
RG = int(input("Digite seu RG: "))  # Solicita o RG do usuário e converte para inteiro
telefone = int(input("Digite seu telefone: "))  # Solicita o telefone do usuário e converte para inteiro
email = input("Digite seu email: ")  # Solicita o e-mail do usuário

# Condicional para verificar a faixa etária e definir os exames necessários
if idade >= 70:  # Se a idade for 70 ou mais
    numero_0a100 = random.randrange(0, 100)  # Gera um número aleatório entre 0 e 99
    print(f"Numero aleatório: {numero_0a100}")  # Exibe o número aleatório gerado
    print("Deverá fazer os mesmos exames mais os exames de Pressão Ocular e Perda Visual")
elif idade >= 50:  # Se a idade for entre 50 e 69 (exclusivo)
    numero_0a100 = random.randrange(0, 100)  # Gera um número aleatório entre 0 e 99
    print(f"Numero aleatório: {numero_0a100}")  # Exibe o número aleatório gerado
    print("Deverá fazer exames de Glaucoma, Miopia e Fundo de Olho")
else:  # Se a idade for menor que 50
    print("A pessoa só retornará para fazer os exames quando completar a idade")

# Condicional para definir o preço da garrafa de água com base na idade
if idade > 50:  # Se a idade for maior que 50
    print("A garrafa de água vai ser R$6,00")  # Exibe o preço da garrafa de água
else:  # Se a idade for 50 ou menos
    print("A garrafa de água vai ser R$10,99")  # Exibe o preço da garrafa de água
