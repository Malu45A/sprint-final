let currentIndex = 0; // Variável para armazenar o índice atual do carrossel

function moveCarousel(direction) { // Função para mover o carrossel
    const carousel = document.querySelector('.carousel-images'); // Seleciona o container das imagens do carrossel
    const images = document.querySelectorAll('.carousel-images img'); // Seleciona todas as imagens do carrossel
    const totalImages = images.length; // Obtém o número total de imagens
    currentIndex = (currentIndex + direction + totalImages) % totalImages; // Calcula o índice da próxima imagem
    const offset = -currentIndex * 100; // Calcula o deslocamento em porcentagem (100% por imagem)
    carousel.style.transform = `translateX(${offset}%)`; // Aplica a transformação para mover o carrossel
}
