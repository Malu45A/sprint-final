// Funções para preencher parágrafos com texto
function primeiro() {
    const paragrafo = document.getElementById('primeiroParagrafo'); // Seleciona o primeiro parágrafo
    // Verifica se o conteúdo do parágrafo está vazio
    if (paragrafo.textContent.trim() === '') {
        // Se estiver vazio, preenche com texto padrão
        paragrafo.textContent = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio sint, iure molestiae, porro facilis ipsam sed natus maiores unde laboriosam totam quisquam praesentium quibusdam ut. Ex voluptate in dolores reiciendis.';
    }
}

// Repete a mesma lógica para os outros parágrafos
function segundo() {
    const paragrafo = document.getElementById('segundoParagrafo');
    if (paragrafo.textContent.trim() === '') {
        paragrafo.textContent = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio sint, iure molestiae, porro facilis ipsam sed natus maiores unde laboriosam totam quisquam praesentium quibusdam ut. Ex voluptate in dolores reiciendis.';
    }
}

function terceiro() {
    const paragrafo = document.getElementById('terceiroParagrafo');
    if (paragrafo.textContent.trim() === '') {
        paragrafo.textContent = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio sint, iure molestiae, porro facilis ipsam sed natus maiores unde laboriosam totam quisquam praesentium quibusdam ut. Ex voluptate in dolores reiciendis.';
    }
}

function quarto() {
    const paragrafo = document.getElementById('quartoParagrafo');
    if (paragrafo.textContent.trim() === '') {
        paragrafo.textContent = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio sint, iure molestiae, porro facilis ipsam sed natus maiores unde laboriosam totam quisquam praesentium quibusdam ut. Ex voluptate in dolores reiciendis.';
    }
}

function quinto() {
    const paragrafo = document.getElementById('quintoParagrafo');
    if (paragrafo.textContent.trim() === '') {
        paragrafo.textContent = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio sint, iure molestiae, porro facilis ipsam sed natus maiores unde laboriosam totam quisquam praesentium quibusdam ut. Ex voluptate in dolores reiciendis.';
    }
}