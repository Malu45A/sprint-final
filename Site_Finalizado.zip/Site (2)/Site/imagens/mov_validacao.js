function validarCadastro() {
    // Regex para validar o nome: apenas permite letras e espaços
    const nomeRegex = /^[a-zA-Z\s]+$/;

    // Regex para validar o email: formato básico de email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    // Obtém o valor do campo "nome" no formulário
    const nome = document.getElementById("nome").value;
    // Obtém o valor do campo "email" no formulário
    const email = document.getElementById("email").value;

    // Verifica se o nome é válido de acordo com a regex
    if (!nomeRegex.test(nome)) {
        // Se o nome for inválido, exibe um alerta
        alert("Nome inválido. Use apenas letras e espaços.");
        // Retorna false para impedir o envio do formulário
        return false;
    }

    // Verifica se o email é válido de acordo com a regex
    if (!emailRegex.test(email)) {
        // Se o email for inválido, exibe um alerta
        alert("E-mail inválido. Insira um e-mail válido.");
        // Retorna false para impedir o envio do formulário
        return false;
    }

    // Se ambos os campos forem válidos, permite o envio do formulário
    return true;
}